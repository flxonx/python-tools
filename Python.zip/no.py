print "Depressing Quotes"
print 'You \n Do Not \n Love Me...'

kms = """
I Want To Die
God, Give Me A Reason Why...
Why I Should Stay Alive
But, He Never Gave Me A Reply
That's Why I Wrote This Script In .py
"""

print "------------------------------"
print kms
print "------------------------------"

print " If You Wanna Die \n Call 18002738255"

# I Wanna Kill Myself