from sys import argv

script, user_name = argv
promt = '> '

print "Python Dox Organizer"
print "By pcoding to %s." % user_name
print "Full Name Of Victim"
name = raw_input(prompt)

print "Where Do They Live?"
live = raw_input(prompt)

print "Online Alias?"
alias = raw_input(promt)

print "Reason Of The Dox?"
reason = raw_input(prompt)

print "Other Info?"
info = raw_input(prompt)

print """
Full Name - %r
Location  - %r
Alias     - %r
Reason    - %r
Misc.     - %r
""" % (name, live, alias, reason, info)