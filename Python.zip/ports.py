# This Is A Simple Script

print "Port Scanner by PCoding"
print "Input IP"
ip = raw_input(prompt)

print "[+] Scanning Quickly..."
print "Scan Is DOne!"

print """
IP You Scanned %r
Ports Open:21, 80,
8000, 8080, 440.  
""" % ip